import java.util.Scanner;

public class input1{
    public static void main(String[] args) {
        int num1;

        Scanner scanner = new Scanner(System.in);
        num1 = scanner.nextInt();
    }
}

