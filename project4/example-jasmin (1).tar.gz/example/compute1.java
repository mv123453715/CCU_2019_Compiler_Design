public class compute1{
    public static void main(String[] args) {
        int num1;
        float b;

        b = 22;
        num1 = (int) (b * 3.14);
    }
}

