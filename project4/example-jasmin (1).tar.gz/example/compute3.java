public class compute3{
    public static void main(String[] args) {
        float a, b;

        b = 22.0f;
        if (b > 0)
           a = 10;
        else
           a = b;
        System.out.println(a); 
    }
}

