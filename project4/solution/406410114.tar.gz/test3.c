  void main ()
  {
    float a;
    float b;
    
    a = 0.5 ;
    b = 0.7 ;
    printf( "a = 0.5 , b = 0.7" );
    if( a >b )
    {
        printf( "a >b is OK!" );
    }
    else
    {
        printf( "a >b is not OK!" );
    }
    
    if( a <b )
    {
        printf( "a <b is OK!" );
    }
    else
    {
        printf( "a <b is not OK!" );
    }
    
    if( a == b )
    {
        printf( "a == b is OK!" );
    }
    else
    {
        printf( "a == b is not OK!" );
    }
    
    if( a != b )
    {
        printf( "a != b is OK!" );
    }
    else
    {
        printf( "a != b is not OK!" );
    }
    
    if( a >=b )
    {
        printf( "a >=b is OK!" );
    }
    else
    {
        printf( "a >=b is not OK!" );
    }
    
    if( a <=b )
    {
        printf( "a <= b is OK!" );
    }
    else
    {
        printf( "a <= b is not OK!" );
    }
    
  }