# �ŧi�ϥ� /bin/bash
#!/bin/bash
#java -cp ./antlr-3.5.2-complete.jar:. myCompiler_test test1.c > test1.j
#java -jar jasmin.jar test1.j
#java myResult
#echo"enter test filename"

rm -f $2
java -cp ./antlr-3.5.2-complete.jar:. myCompiler_test $1 > $2
java -jar jasmin.jar $2
echo "java -jar jasmin.jar   OK!"
echo "java myResult"
java myResult