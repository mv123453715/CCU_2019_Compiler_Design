  void main ()
  {
    int a;
    float b;
    
    a = 5;
    b = 0.5;
    printf( "HELLO WORLD");
    printf( "a= %d",a );
    printf( "b =%f",b );
    
    
  }