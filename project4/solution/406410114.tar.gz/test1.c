

void main()
{
   int a;
   int b;
   float c;
   a = 0;
   c = 0.0;
   printf( "Test1 int float is OK!\n" ); 

}
