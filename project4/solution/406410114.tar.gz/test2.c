void main()
{
   int a;
   int b;
   
   b=2;

   a=b+2*(100-1);
   printf( "Test2 Statements for arithmetic computation OK!\n" ); 
}
