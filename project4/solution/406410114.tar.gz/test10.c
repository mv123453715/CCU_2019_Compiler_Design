void main()
{
   int a;

   a = 20;
   printf("Hello World\n");
}
