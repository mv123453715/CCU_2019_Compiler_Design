  void main ()
  {
    int a;
    int b;
    
    a = 5 ;
    b = 7 ;
    printf( "a = 5 , b = 7" );
    if( a >b )
    {
        printf( "a >b is OK!" );
    }
    else
    {
        printf( "a >b is not OK!" );
    }
    
    if( a <b )
    {
        printf( "a <b is OK!" );
    }
    else
    {
        printf( "a <b is not OK!" );
    }
    
    if( a == b )
    {
        printf( "a == b is OK!" );
    }
    else
    {
        printf( "a == b is not OK!" );
    }
    
    if( a != b )
    {
        printf( "a != b is OK!" );
    }
    else
    {
        printf( "a != b is not OK!" );
    }
    
    if( a >=b )
    {
        printf( "a >=b is OK!" );
    }
    else
    {
        printf( "a >=b is not OK!" );
    }
    
    if( a <=b )
    {
        printf( "a <= b is OK!" );
    }
    else
    {
        printf( "a <= b is not OK!" );
    }
    
  }