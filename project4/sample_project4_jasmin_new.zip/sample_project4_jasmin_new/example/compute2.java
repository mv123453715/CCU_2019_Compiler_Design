public class compute2{
    public static void main(String[] args) {
        int num1;
        float b;

        b = 22.0f;
        num1 = (int) (b * 3.14f);
        System.out.println(num1); 
    }
}

