public class hello2{
    public static void func() {
       return;
    }

    public static void main(String[] args) {
        System.out.println("Hello! World!");
        func();
    }
}

