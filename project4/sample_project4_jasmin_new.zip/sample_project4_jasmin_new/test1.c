int a;
int b;

int main()
{
   a = 0;
   b = a + 100;

   return 0;
}
