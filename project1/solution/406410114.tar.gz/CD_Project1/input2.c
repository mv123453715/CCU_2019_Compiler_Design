#include <stdio.h>

int main()
{
    int a;
    char c ;
    float f1,f2;
    scanf( "%d",&a );
    printf( "a is %d\n",a );
    retunr 0;
    
}//main()
