void main()
{
		int a = 0;
    float b = 5.5;
    int c=  5;
    
    c = a+b;
    c = a-b;
    c = a*b;
		c = a/b;
       

    
}
