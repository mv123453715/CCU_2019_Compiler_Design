void main()
{
		int a =2;
    int b = 3;
    int c;
    if ( a >=b )
        a = a+b;
    
       

    
}
