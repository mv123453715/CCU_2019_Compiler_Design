void main()
{
		int a =2;
    int b = 3;
    int c;
    for ( int i = 0; i = a+b ; i++ )
        a = b;
    
       

    
}
