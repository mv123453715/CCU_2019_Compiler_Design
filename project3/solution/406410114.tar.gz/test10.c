void main()
{
		int a = 0;
		int b;

		if ( a == 2 ){
       b = 5;
    }
    else if ( a = b+1 ){
       b = 4;
    }
    else if ( a = b+1 ){
       b = 3;
    }
    else
        b = 2;
}
