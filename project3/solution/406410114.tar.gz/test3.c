void main()
{
		int a = 0;
    int c = 5;
    c = a+1.0;
    c = a*1.0;
		c = a/1.0;
       

    
}
