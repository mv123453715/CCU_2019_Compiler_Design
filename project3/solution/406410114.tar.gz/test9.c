void main()
{
		int a = 5;
		float b = 10.0;

    a += b;
    a -= b;
    a *= b;
    a /= b;
    a %= b;
   
}
