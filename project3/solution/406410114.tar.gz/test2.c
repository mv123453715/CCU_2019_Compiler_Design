void main()
{
		int a ;
		float a;
    }
}
