void main()
{
		a = 1 +1 ;
    
}
