void main()
{
		int a;
		float b;

		a = b+1;
}
