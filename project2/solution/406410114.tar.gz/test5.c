void main()
{
		int a = 1;
		float b;

		while ( a == 10 ){
       a = b +1;
   
   }
   
}