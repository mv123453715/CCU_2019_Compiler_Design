void main()
{
    int b = 2;  
    int* pointer; 
    pointer = &b; 
   
}