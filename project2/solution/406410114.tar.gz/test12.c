#include <stdio.h>
#include <stdlib.h>
void main()
{
		int a;
		float b;

		a = b+1;
}
