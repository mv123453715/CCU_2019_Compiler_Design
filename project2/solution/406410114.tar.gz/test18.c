void main()
{
		float b;
    for ( int a = 0 ; a <= 10 ; a++ )
        b--;
}
