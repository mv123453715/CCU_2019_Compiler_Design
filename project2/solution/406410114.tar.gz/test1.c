void main()
{
		int a;
		float b;

		a = b+1;
    a = b-1;
    a = b*1;
    a = b/1;
    a = ((b+a)*(b-a)*(b*a)*(b/a));
}
