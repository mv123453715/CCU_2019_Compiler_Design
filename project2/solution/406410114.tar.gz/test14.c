void main()
{
    int score = 98;
    switch(score / 10) { 
        case 9: 
            printf("get A"); 
            break; 
        case 8: 
            printf("get B"); 
            break; 
        case 7: 
            printf("get C"); 
            break; 
        case 6: 
            printf("get D"); 
            break; 
        default: 
            printf("get E"); 
            break;
    } 
}