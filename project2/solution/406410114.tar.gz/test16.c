void main()
{
		int a = 0;
		float b;

		if ( a == 2 ){
       b = 5;
    }
    else if ( a== 3 ){
       b = 4;
    }
    else if ( a== 5 ){
       b = 3;
    }
    else
        b = 2;
}
