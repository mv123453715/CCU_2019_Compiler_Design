void main()
{
		int a = 1;
		float b;
 
		scanf( "%d",a ); 
    scanf( "%d%f",a,b ); 
   
}