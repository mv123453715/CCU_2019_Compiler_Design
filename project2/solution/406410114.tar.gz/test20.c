void main()
{
		int a = 5;
		int b = 10;

    a += b;
    a -= b;
    a *= b;
    a /= b;
    a %= b;
   
}
