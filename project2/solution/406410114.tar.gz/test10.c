void main()
{
		int a = 1;
		float b;
    double c = 0.5;
		for ( int i = 0;i <= 5 ; i=i+1 ){
       a = b +1;
       for ( int j = 0; i <= 10; j= j+1 )
         a = b -1;
   }
   
}