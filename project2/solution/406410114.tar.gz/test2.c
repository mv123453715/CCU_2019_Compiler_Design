void main()
{
		int a = 0;
		float b;

		if ( a == 2 )
       b = 5+3;
    
    if ( a == 2 ){
       b = a;
    }
}
