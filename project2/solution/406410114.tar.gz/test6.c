void main()
{
		int a = 1;
		float b;

    printf( "aaa" ); 
		printf( "a:%d",a ); 
    printf( "a,b:%d%d",a,b ); 
   
}