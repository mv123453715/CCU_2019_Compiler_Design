int add ( int a, int b, ){
    int c = 5;
    c = a+b;
    return c ;


}

char compare( char c1, char c2 ){
    int i;
    if ( c1 == c2 )
        i = 1;
    return c1;
}

double mul ( double d1 ,double d2 ){
    double result ;
    result = d1*d2;
    return   result;

}

void main()
{
		int a = 5;
		int b = 10;

    add( a,b );
}


