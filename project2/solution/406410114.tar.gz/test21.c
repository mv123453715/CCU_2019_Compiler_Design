int add ( int a, int b, ){
    int c = 5;
    c = a+b;
    return c ;


}

void main()
{
		int a = 5;
		int b = 10;

    add( a,b );
}


