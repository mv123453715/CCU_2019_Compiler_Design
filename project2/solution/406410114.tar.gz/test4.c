void main()
{
		int a = 1;
		float b;

		for ( int i = 0;i <= 5 ; i=i+1 ){
       a = b +1;
   }
   
}