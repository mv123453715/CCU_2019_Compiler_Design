void main()
{
		int a = 0;
		float b;

		if ( a == 2 ){
       b = 5;
       if ( a >=3 )
           b = 2;
       else
           b = 6;
    }
    else {
       b = 3;
    }
       

    
}
