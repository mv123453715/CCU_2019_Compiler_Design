void main()
{
		int a = 1;
		float b;

		if ( a == 10 )
       b = 0;
    if ( a >= 10 )
       b = 1;
    if ( a <= 10 )
       b = 2;
    if ( a != 10 )
       b = 3;
    if ( a > 10 )
       b = 4;
    if ( a < 10 )
       b = 5;

   
}